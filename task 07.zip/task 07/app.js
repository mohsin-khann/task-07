const express = require('express');
const fs = require('fs');
const nodemailer = require('nodemailer');

const app = express();
const port = 3000;

const emailContent = fs.readFileSync('email.txt', 'utf8');

app.get('/email', (req, res) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Emails text sender </title>
      <style>
        #notification {
          display: none;
          padding: 10px;
          background-color: #4CAF50;
          color: white;
          margin-top: 10px;
        }
      </style>
    </head>

    <body>
      <h1>Emails</h1>
      <p>${emailContent}</p>
      <form action="/send-email" method="post">
        <button type="submit">Send Email</button>
      </form>
      <div id="notification"></div>
      <script>
        const notification = document.getElementById('notification');
        if (window.location.search.includes('email-sent=true')) {
          notification.style.backgroundColor = '#4CAF50';
          notification.innerText = 'Email sent successfully!';
          notification.style.display = 'block';
        }
      </script>
    </body>
    </html>
  `;

  res.send(htmlContent);
});


app.post('/send-email', (req, res) => {

 const emailContent = fs.readFileSync('email.txt', 'utf8');

 const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'mohsin@gmail.com', 
      pass: 'abc' 
    }
  });

  
  const mailOptions = {
    from: 'mohsin@gmail.com', 
    to: 'def@example.com', 
    subject: 'Read data from the Text file',
    text: emailContent
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.error('Error sending email:', error);
    }
    console.log('Email sent:', info.response);
  });

  res.redirect('/email');
});


app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}/email`);
});
